/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finddates;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Fabien Lavielle
 * @version 1.0
 */
public class FindDates {

    /**
     * Constants
     */
    //Pattern for dates with the format yyyy-mm-dd -> ex : 2016-04-07
    private static final String C_DATE_PATTERN1 = "([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})";
    //Pattern for dates with the format Month dd, yyyy -> ex : May 15, 2014
    private static final String C_DATE_PATTERN2 = "([a-zA-Z]+)\\s([0-9]{1,2}),\\s([0-9]{4})";
    //Pattern for dates with the format dd Month yyyy -> ex : 20 May 2014
    private static final String C_DATE_PATTERN3 = "([0-9]{1,2})\\s([a-zA-Z]+)\\s([0-9]{4})";
    private static final String C_DATE_PATTERNS = C_DATE_PATTERN1 + "|" + C_DATE_PATTERN2 + "|" + C_DATE_PATTERN3;

    //Dates formats which find in text
    private static final String C_FORMAT_DATE_1 = "dd MMMMM yyyy";
    private static final String C_FORMAT_DATE_2 = "MMMMM dd, yyyy";
    private static final String C_FORMAT_DATE_3 = "yyyy-MM-dd";

    //Input file which contains the text
    private static final String C_PATH_TEXT = "D:\\Projet_Perso\\Find_Dates_V1\\src\\res\\sample_text.txt";
    //Output file
    private static final String C_FILE_OUTPUT = "D:\\Projet_Perso\\Find_Dates_V1\\src\\res\\output.txt";

    /**
     * Variables
     */
    //Dates extracted list
    private static ArrayList<String> M_datesExtract;
    //Dates format list
    private static ArrayList<SimpleDateFormat> M_formatDates;
    //Dates formatted with the final date format 
    private static ArrayList<String> M_datesFormatted;

    public static void main(String[] args) throws ParseException, IOException {
        /**
         * Lists initialization
         */
        InitLists();

        /**
         * File reading, regex utilization to identifie dates, creation of the
         * list of extracted dates
         */
        ExtractDates();

        /**
         * Formatting dates in a unique format
         */
        FormatDates();

        /**
         * Sort the list in ascending order
         */
        SortList();

        /**
         * Count dates
         */
        CountDates();

        /**
         * Creation of output file
         */
        GenerateOutput();
    }

    private static void InitLists() {
        M_formatDates = new ArrayList<SimpleDateFormat>();
        M_datesExtract = new ArrayList<String>();
        M_datesFormatted = new ArrayList<String>();

        M_formatDates.add(new SimpleDateFormat(C_FORMAT_DATE_1, Locale.US));
        M_formatDates.add(new SimpleDateFormat(C_FORMAT_DATE_2, Locale.US));
        M_formatDates.add(new SimpleDateFormat(C_FORMAT_DATE_3, Locale.US));
    }

    private static void ExtractDates() throws FileNotFoundException, IOException {
        InputStream input;
        InputStreamReader read;
        BufferedReader buff;
        String line;
        Pattern regPattern;
        Matcher regMatches;

        input = new FileInputStream(C_PATH_TEXT);
        read = new InputStreamReader(input);
        buff = new BufferedReader(read);

        regPattern = Pattern.compile(C_DATE_PATTERNS);

        //Checking line per line of the input file if it contains dates
        while ((line = buff.readLine()) != null) {
            regMatches = regPattern.matcher(line);
            while (regMatches.find()) {
                M_datesExtract.add(regMatches.group());
            }
        }

        buff.close();
    }

    private static void FormatDates() {
        SimpleDateFormat formatDateFinal;
        Date date;

        formatDateFinal = new SimpleDateFormat(C_FORMAT_DATE_3);

        //Formatting all extracted dates in yyyy-mm-dd format
        for (int i = 0; i < M_datesExtract.size(); i++) {
            for (int j = 0; j < M_formatDates.size(); j++) {
                try {
                    date = M_formatDates.get(j).parse(M_datesExtract.get(i));
                    M_datesFormatted.add(formatDateFinal.format(date));
                } catch (ParseException ex) {
                }
            }
        }
    }

    private static void SortList() throws ParseException {
        String temp;

        for (int i = M_datesFormatted.size() - 1; i >= 0; i--) {
            for (int j = 0; j <= i - 1; j++) {
                if (M_datesFormatted.get(j + 1).compareTo(M_datesFormatted.get(j)) < 0) {
                    temp = M_datesFormatted.get(j);
                    M_datesFormatted.set(j, M_datesFormatted.get(j + 1));
                    M_datesFormatted.set(j + 1, temp);
                }

            }
        }
    }

    private static void CountDates() throws ParseException {
        int count;

        for (int i = M_datesFormatted.size() - 1; i >= 0; i--) {
            count = 1;
            for (int j = 0; j <= i - 1; j++) {
                //If two dates are equals, I increment count and delete one of dates.
                //Next, I concat the date with (count)
                if (M_datesFormatted.get(j).compareTo(M_datesFormatted.get(j + 1)) == 0) {
                    count++;
                    M_datesFormatted.remove(j + 1);
                    i--;
                    M_datesFormatted.set(j, M_datesFormatted.get(j) + "(" + count + ")");
                } else {
                    count = 1;
                }
            }
            if (!M_datesFormatted.get(i).contains("(")) {
                M_datesFormatted.set(i, M_datesFormatted.get(i) + "(" + count + ")");
            }
        }
    }

    private static void GenerateOutput() throws IOException {
        File file;
        FileWriter fw;
        String[] split;
        String year = "";
        String month = "";

        //Creation of output file
        file = new File(C_FILE_OUTPUT);
        file.createNewFile();

        fw = new FileWriter(file);

        for (int i = 0; i < M_datesFormatted.size(); i++) {
            //I split date
            split = M_datesFormatted.get(i).split("-");

            //I check if the year and/or the month they are equals with the current date
            if (year.equals("") && month.equals("")) {
                fw.write(split[0] + ":\r\n" + "\t-" + split[1] + "\r\n" + "\t\t-" + split[2] + "\r\n");
                System.out.println(split[0] + ":\r\n" + "\t-" + split[1] + "\r\n" + "\t\t-" + split[2] + "\r\n");
            } else {
                if (month.equals(split[0] + "-" + split[1])) {
                    fw.write("\t\t-" + split[2] + "\r\n");
                    System.out.println("\t\t-" + split[2] + "\r\n");
                } else {
                    if (year.equals(split[0])) {
                        fw.write("\t-" + split[1] + "\r\n" + "\t\t-" + split[2] + "\r\n");
                        System.out.println("\t-" + split[1] + "\r\n" + "\t\t-" + split[2] + "\r\n");
                    } else {
                        fw.write(split[0] + ":\r\n" + "\t-" + split[1] + "\r\n" + "\t\t-" + split[2] + "\r\n");
                        System.out.println(split[0] + ":\r\n" + "\t-" + split[1] + "\r\n" + "\t\t-" + split[2] + "\r\n");
                    }
                }
            }
            
            //I save the year and the month to check if they are already use
            year = split[0];
            month = split[0] + "-" + split[1];
        }
        fw.close();
    }
}
